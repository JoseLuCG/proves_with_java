import java.util.Scanner;

public class Ejercicio12_pag42 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        System.out.println("");

    }
}
